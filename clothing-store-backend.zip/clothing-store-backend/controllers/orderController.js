const Order = require("../models/Order");

// Get User's Order History
exports.getOrderHistory = async (req, res) => {
  try {
    const orders = await Order.find({ user: req.user._id }).populate("products.product", "name price");
    res.send(orders);
  } catch (error) {
    res.status(500).send("Error fetching order history");
  }
};

// Update Order Status
exports.updateOrderStatus = async (req, res) => {
  try {
    const { status } = req.body;

    // Check if the new status is valid
    if (!["Ordered", "Delivered", "Cancelled"].includes(status)) {
      return res.status(400).send("Invalid status");
    }

    // Find and update the order's status
    const order = await Order.findById(req.params.id);
    if (!order) return res.status(404).send("Order not found");

    // Allow only specific status changes
    if (order.status === "Delivered") {
      return res.status(400).send("Delivered orders cannot be updated");
    }
    if (order.status === "Cancelled") {
      return res.status(400).send("Cancelled orders cannot be updated");
    }

    // Update status only if it's a valid change
    order.status = status;
    await order.save();

    res.send(order);
  } catch (error) {
    res.status(500).send("Error updating order status");
  }
};

