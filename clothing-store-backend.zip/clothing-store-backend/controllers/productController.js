const Product = require("../models/Product");

// Get All Products with Filtering
exports.getAllProducts = async (req, res) => {
  try {
    const { category, minPrice, maxPrice, color, size } = req.query;
    const filter = {};

    // Apply category filter if provided
    if (category) {
      filter.category = category;
    }

    // Apply price range filter if provided
    if (minPrice || maxPrice) {
      filter.price = {};
      if (minPrice) filter.price.$gte = Number(minPrice);
      if (maxPrice) filter.price.$lte = Number(maxPrice);
    }

    // Apply size filter if provided
    if (size) {
      filter.size = size;
    }

    // Fetch filtered products
    const products = await Product.find(filter);
    res.send(products);
  } catch (error) {
    res.status(500).send("Error fetching products");
  }
};

// Get Product by ID (for product detail view)
exports.getProductById = async (req, res) => {
  try {
    const product = await Product.findById(req.params.id);
    if (!product) return res.status(404).send("Product not found");
    res.send(product);
  } catch (error) {
    res.status(500).send("Error fetching product details");
  }
};

