const User = require("../models/User");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const Order = require("../models/Order");

// Register a New User
exports.register = async (req, res) => {
  try {
    const { email, password, username } = req.body;
    let user = await User.findOne({ email });
    if (user) return res.status(400).send("User already exists.");

    user = new User({ email, username });
    user.password = await user.hashPassword(password);
    await user.save();

    const token = user.generateAuthToken();
    res.send({ token });
  } catch (error) {
    console.error("Registration error:", error.message);
    res.status(500).send("Error registering user");
  }
};

// Login a User
exports.login = async (req, res) => {
  try {
    const { email, password } = req.body;
    const user = await User.findOne({ email });
    if (!user) return res.status(400).send("User not found.");

    const validPassword = await bcrypt.compare(password, user.password);
    if (!validPassword) return res.status(400).send("Invalid password.");

    const token = user.generateAuthToken();
    res.send({ token });
  } catch (error) {
    console.error("Login error:", error.message);
    res.status(500).send("Error logging in");
  }
};

// Get User's Cart
exports.getCart = async (req, res) => {
  try {
    const user = await User.findById(req.user._id).populate("cart.product", "name price");
    if (!user) return res.status(404).send("User not found");

    res.send(user.cart);
  } catch (error) {
    res.status(500).send("Error fetching cart");
  }
};

// Add or Update Item in Cart
exports.addToCart = async (req, res) => {
  try {
    const userId = req.user._id;
    const { productId, quantity } = req.body;

    const user = await User.findById(userId);
    if (!user) return res.status(404).send("User not found");

    const cartItem = user.cart.find(item => item.product.toString() === productId);

    if (cartItem) {
      cartItem.quantity = quantity;
    } else {
      user.cart.push({ product: productId, quantity });
    }

    await user.save();
    res.send(user.cart);
  } catch (error) {
    res.status(500).send("Error updating cart");
  }
};

// Remove Item from Cart
exports.removeFromCart = async (req, res) => {
  try {
    const userId = req.user._id;
    const { productId } = req.params;

    const user = await User.findById(userId);
    if (!user) return res.status(404).send("User not found");

    user.cart = user.cart.filter(item => item.product.toString() !== productId);
    await user.save();

    res.send(user.cart);
  } catch (error) {
    res.status(500).send("Error removing item from cart");
  }
};

// Checkout: Convert Cart to Order
exports.checkout = async (req, res) => {
  try {
    const userId = req.user._id;
    const { shippingAddress } = req.body;

    const user = await User.findById(userId).populate("cart.product");
    if (!user) return res.status(404).send("User not found");
    if (user.cart.length === 0) return res.status(400).send("Cart is empty");

    const totalAmount = user.cart.reduce((sum, item) => sum + item.product.price * item.quantity, 0);

    const order = new Order({
      user: userId,
      products: user.cart,
      totalAmount,
      shippingAddress,
      status: "Ordered",
      orderDate: Date.now(),
    });
    await order.save();

    user.cart = [];
    user.orderHistory.push(order._id);
    await user.save();

    res.send(order);
  } catch (error) {
    res.status(500).send("Error during checkout");
  }
};
