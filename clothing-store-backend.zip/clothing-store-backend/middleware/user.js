const jwt = require("jsonwebtoken");

module.exports = (req, res, next) => {
  const token = req.header("Authorization"); // Get the token from the Authorization header
  if (!token) return res.status(401).send("Access denied. No token provided.");

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET); // Verify the token
    req.user = decoded; // Attach the user payload to the request object
    next(); // Proceed to the next middleware or route handler
  } catch (err) {
    res.status(400).send("Invalid token.");
  }
};
