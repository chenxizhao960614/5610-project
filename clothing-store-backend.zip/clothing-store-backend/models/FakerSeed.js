const mongoose = require("mongoose");
const { faker } = require("@faker-js/faker"); // Updated import

const Product = require("./Product");
const User = require("./User");
const Order = require("./Order");

// MongoDB connection
require("dotenv").config();

mongoose.connect(process.env.MONGODB_URI)
  .then(() => console.log("Connected to MongoDB"))
  .catch((err) => console.error("MongoDB connection error:", err));


// Seed products
const seedProducts = async (num) => {
  const products = [];
  for (let i = 0; i < num; i++) {
    products.push({
      name: faker.commerce.product(),
      category: faker.commerce.department(),
      price: parseFloat(faker.commerce.price()),
      size: faker.helpers.arrayElement(["S", "M", "L", "XL"]),
      description: faker.commerce.productDescription(),
      imageUrl: `https://source.unsplash.com/640x480/?fashion,clothing`,
    });
  }
  await Product.insertMany(products);
  console.log(`${num} products seeded`);
};


// Seed users
const seedUsers = async (num) => {
  const users = [];
  for (let i = 0; i < num; i++) {
    users.push({
      username: faker.internet.userName(),
      email: faker.internet.email(),
      password: faker.internet.password(),
      cart: [],
      orderHistory: [],
    });
  }
  await User.insertMany(users);
  console.log(`${num} users seeded`);
};

// Seed orders
const seedOrders = async (num) => {
  const users = await User.find();
  const products = await Product.find();

  // Check if users and products have been seeded
  if (users.length === 0 || products.length === 0) {
    console.log("Ensure users and products are seeded before running order seeds.");
    return;
  }

  const orders = [];

  for (let i = 0; i < num; i++) {
    const user = faker.helpers.arrayElement(users); // Select random user
    const selectedProducts = faker.helpers.arrayElements(products, 3); // Select 3 random products
    const orderProducts = selectedProducts.map((product) => ({
      product: product._id,
      quantity: faker.number.int({ min: 1, max: 5 }), // Generate a random quantity between 1 and 5
    }));

    const totalAmount = orderProducts.reduce(
      (sum, item) => sum + item.quantity * products.find((p) => p._id.equals(item.product)).price,
      0
    );

    orders.push({
      user: user._id,
      products: orderProducts,
      totalAmount,
      shippingAddress: faker.location.streetAddress(), // Updated to match new faker API
      status: faker.helpers.arrayElement(["Ordered", "Delivered", "Cancelled"]), // Select random order status
    });
  }

  await Order.insertMany(orders);
  console.log(`${num} orders seeded`);
};

// Main function to seed data
const seedDatabase = async () => {
  try {
    await seedProducts(50); // Generate 50 products
    await seedUsers(20);    // Generate 20 users
    await seedOrders(30);   // Generate 30 orders
    mongoose.disconnect();
    console.log("Database populated successfully");
  } catch (err) {
    console.error("Error populating database:", err);
  }
};

seedDatabase();
