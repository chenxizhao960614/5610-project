const express = require("express");
const { getOrderHistory, updateOrderStatus } = require("../controllers/orderController");
const auth = require("../middleware/user");

const router = express.Router();

router.get("/history", auth, getOrderHistory); // Get user's order history
router.patch("/:id/status", auth, updateOrderStatus); // Update order status

module.exports = router;

