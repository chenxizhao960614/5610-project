const express = require("express");
const {
  getAllProducts,
  getProductById,
} = require("../controllers/productController");

const router = express.Router();

router.get("/", getAllProducts); // Fetch products with filters
router.get("/:id", getProductById); // Get specific product details

module.exports = router;
