const express = require("express");
const {
  register,
  login,
  getCart,
  addToCart,
  removeFromCart,
  checkout,
} = require("../controllers/userController");
const auth = require("../middleware/user");

const router = express.Router();

router.post("/register", register); // Register a user
router.post("/login", login); // Login a user
router.get("/cart", auth, getCart); // Get user's cart
router.post("/cart", auth, addToCart); // Add or update item in cart
router.delete("/cart/item/:productId", auth, removeFromCart); // Remove item from cart
router.post("/cart/checkout", auth, checkout); // Checkout and clear cart

module.exports = router;
